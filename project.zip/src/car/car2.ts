import {
  Quaternion,
  Vector3,
  Vector4,
} from "@babylonjs/core/Maths/math.vector";
import { AnimationGroup } from "@babylonjs/core/Animations/animationGroup";
import { AbstractMesh } from "@babylonjs/core/Meshes/abstractMesh";
import { Scene } from "@babylonjs/core/scene";
import { SceneLoader } from "@babylonjs/core/Loading/sceneLoader";
import {
  Camera,
  Color3,
  MeshBuilder,
  StandardMaterial,
  Texture,
  Mesh,
  Axis,
  Space,
  SolidParticleSystem,
  ActionManager,
  ExecuteCodeAction,
  Engine,
  Color4,
  AmmoJSPlugin,
  PhysicsImpostor,
  VertexBuffer,
  FollowCamera,
} from "@babylonjs/core";
import { GridMaterial } from "@babylonjs/materials";
import Ammo from 'ammojs-typed';

export default class Car {
  keysActions: any = {
    KeyW: "acceleration",
    KeyS: "braking",
    KeyA: "left",
    KeyD: "right",
  };
  actions: any = { accelerate: false, brake: false, right: false, left: false };

  wheelAxisPositionBack = -1;
  wheelRadiusBack = 0.4;
  wheelWidthBack = 0.3;
  wheelHalfTrackBack = 1;
  wheelAxisHeightBack = 0.4;

  wheelAxisFrontPosition = 1.0;
  wheelHalfTrackFront = 1;
  wheelAxisHeightFront = 0.4;
  wheelRadiusFront = 0.4;
  wheelWidthFront = 0.3;
  FRONT_LEFT = 0;
  FRONT_RIGHT = 1;
  BACK_LEFT = 2;
  BACK_RIGHT = 3;

  vehicleReady = false;

  wheelDirectionCS0: any;
  wheelAxleCS: any;

  friction = 5;
  suspensionStiffness = 10;
  suspensionDamping = 0.3;
  suspensionCompression = 4.4;
  suspensionRestLength = 0.6;
  rollInfluence = 0.0;

  steeringIncrement = 0.01;
  steeringClamp = 0.2;
  maxEngineForce = 500;
  maxBreakingForce = 10;
  incEngine = 10.0;

  wheelMeshes: any = [];

  constructor(public scene: Scene, public camera: any) {}

  public addCar() {
    let scene = this.scene;
    let edMaterial: any,
      redMaterial: any,
      blueMaterial: any,
      greenMaterial: any,
      blackMaterial: any;

    var chassisMesh;

    edMaterial = new StandardMaterial("RedMaterial", scene);
    redMaterial.diffuseColor = new Color3(0.8, 0.4, 0.5);
    redMaterial.emissiveColor = new Color3(0.8, 0.4, 0.5);

    blueMaterial = new StandardMaterial("RedMaterial", scene);
    blueMaterial.diffuseColor = new Color3(0.5, 0.4, 0.8);
    blueMaterial.emissiveColor = new Color3(0.5, 0.4, 0.8);

    greenMaterial = new StandardMaterial("RedMaterial", scene);
    greenMaterial.diffuseColor = new Color3(0.5, 0.8, 0.5);
    greenMaterial.emissiveColor = new Color3(0.5, 0.8, 0.5);

    blackMaterial = new StandardMaterial("RedMaterial", scene);
    blackMaterial.diffuseColor = new Color3(0.1, 0.1, 0.1);
    blackMaterial.emissiveColor = new Color3(0.1, 0.1, 0.1);

    // Enable physics
    scene.enablePhysics(new Vector3(0, -10, 0), new AmmoJSPlugin());

    this.wheelDirectionCS0 = new Ammo.btVector3(0, -1, 0);
    this.wheelAxleCS = new Ammo.btVector3(-1, 0, 0);

    var ground = Mesh.CreateGround("ground", 460, 460, 2, scene);
    ground.physicsImpostor = new PhysicsImpostor(
      ground,
      PhysicsImpostor.BoxImpostor,
      { mass: 0, friction: 0.5, restitution: 0.7 },
      scene
    );
    ground.material = new GridMaterial("groundMaterial", scene);

    this.createBox(
      new Vector3(4, 1, 12),
      new Vector3(0, 0, 25),
      new Vector3(-Math.PI / 8, 0, 0),
      0,
      redMaterial,
      blueMaterial
    );
    this.createBox(
      new Vector3(4, 1, 12),
      new Vector3(25, 0, 0),
      new Vector3(-Math.PI / 8, Math.PI / 2, 0),
      0,
      redMaterial,
      blueMaterial
    );
    this.createBox(
      new Vector3(4, 1, 12),
      new Vector3(0, 0, -25),
      new Vector3(Math.PI / 8, 0, 0),
      0,
      redMaterial,
      blueMaterial
    );
    this.createBox(
      new Vector3(4, 1, 12),
      new Vector3(-25, 0, 0),
      new Vector3(Math.PI / 8, Math.PI / 2, 0),
      0,
      redMaterial,
      blueMaterial
    );

    let s = new Vector3();
    let p = new Vector3();
    let r = new Vector3();
    for (let i = 0; i < 20; i++) {
      let m = Math.random() * 300 - 150 + 5;
      let m3 = Math.random() * 300 - 150 + 5;
      let m2 = Math.random() * 10;
      s.set(m2, m2, m2);
      p.set(m3, 0, m);
      r.set(m, m, m);
      this.createBox(s, p, r, 0, redMaterial, blueMaterial);
    }

    for (let i = 0; i < 30; i++) {
      let m = Math.random() * 300 - 150 + 5;
      let m3 = Math.random() * 300 - 150 + 5;
      let m2 = Math.random() * 3;
      s.set(m2, m2, m2);
      p.set(m3, 0, m);
      r.set(m, m, m);
      this.createBox(s, p, r, 5, redMaterial, blueMaterial);
    }

    this.loadTriangleMesh(redMaterial);

    var ZERO_QUATERNION = new Quaternion();

    this.createVehicle(
      new Vector3(0, 4, -20),
      ZERO_QUATERNION,
      greenMaterial,
      blackMaterial
    );

    window.addEventListener("keydown", this.keydown);
    window.addEventListener("keyup", this.keyup);
  }

  createBox(
    size: any,
    position: any,
    rotation: any,
    mass: any,
    redMaterial: any,
    blueMaterial: any
  ) {
    let scene = this.scene;

    var box = MeshBuilder.CreateBox(
      "box",
      { width: size.x, depth: size.z, height: size.y },
      scene
    );
    box.position.set(position.x, position.y, position.z);
    box.rotation.set(rotation.x, rotation.y, rotation.z);
    if (!mass) {
      mass = 0;
      box.material = redMaterial;
    } else {
      box.position.y += 5;
      box.material = blueMaterial;
    }
    box.physicsImpostor = new PhysicsImpostor(
      box,
      PhysicsImpostor.BoxImpostor,
      { mass: mass, friction: 0.5, restitution: 0.7 },
      scene
    );
  }

  loadTriangleMesh(redMaterial: any) {
    let scene = this.scene;
    var physicsWorld = scene.getPhysicsEngine().getPhysicsPlugin().world;
    SceneLoader.ImportMesh(
      "Loft001",
      "https://raw.githubusercontent.com/RaggarDK/Baby/baby/",
      "ramp.babylon",
      scene,
      function (newMeshes) {
        for (let x = 0; x < newMeshes.length; x++) {
          let mesh = newMeshes[x];
          mesh.position.y -= 2.5;
          mesh.material = redMaterial;
          let positions = mesh.getVerticesData(VertexBuffer.PositionKind);
          let normals = mesh.getVerticesData(VertexBuffer.NormalKind);
          let colors = mesh.getVerticesData(VertexBuffer.ColorKind);
          let uvs = mesh.getVerticesData(VertexBuffer.UVKind);
          let indices = mesh.getIndices();

          mesh.updateFacetData();
          var localPositions = mesh.getFacetLocalPositions();
          var triangleCount = localPositions.length;

          let mTriMesh = new Ammo.btTriangleMesh();
          let removeDuplicateVertices = true;
          let tmpPos1 = new Ammo.btVector3(0, 0, 0);
          let tmpPos2 = new Ammo.btVector3(0, 0, 0);
          let tmpPos3 = new Ammo.btVector3(0, 0, 0);

          var _g = 0;
          while (_g < triangleCount) {
            var i = _g++;
            var index0 = indices[i * 3];
            var index1 = indices[i * 3 + 1];
            var index2 = indices[i * 3 + 2];
            var vertex0 = new Ammo.btVector3(
              positions[index0 * 3],
              positions[index0 * 3 + 1],
              positions[index0 * 3 + 2]
            );
            var vertex1 = new Ammo.btVector3(
              positions[index1 * 3],
              positions[index1 * 3 + 1],
              positions[index1 * 3 + 2]
            );
            var vertex2 = new Ammo.btVector3(
              positions[index2 * 3],
              positions[index2 * 3 + 1],
              positions[index2 * 3 + 2]
            );
            mTriMesh.addTriangle(vertex0, vertex1, vertex2);
          }

          let shape = new Ammo.btBvhTriangleMeshShape(mTriMesh, true, true);
          let localInertia = new Ammo.btVector3(0, 0, 0);
          let transform = new Ammo.btTransform();

          transform.setIdentity();
          transform.setOrigin(
            new Ammo.btVector3(
              mesh.position.x,
              mesh.position.y,
              mesh.position.z
            )
          );
          transform.setRotation(
            new Ammo.btQuaternion(
              mesh.rotationQuaternion.x,
              mesh.rotationQuaternion.y,
              mesh.rotationQuaternion.z,
              mesh.rotationQuaternion.w
            )
          );

          let motionState = new Ammo.btDefaultMotionState(transform);
          let rbInfo = new Ammo.btRigidBodyConstructionInfo(
            0,
            motionState,
            shape,
            localInertia
          );
          let body = new Ammo.btRigidBody(rbInfo);
          physicsWorld.addRigidBody(body);
        }
      }
    );
  }

  createVehicle(pos: any, quat: any, greenMaterial: any, blackMaterial: any) {
    //Going Native

    let scene = this.scene;
    var massVehicle = 200;

    var chassisWidth = 1.8;
    var chassisHeight = 0.6;
    var chassisLength = 4;

    var physicsWorld = scene.getPhysicsEngine().getPhysicsPlugin().world;

    var geometry = new Ammo.btBoxShape(
      new Ammo.btVector3(
        chassisWidth * 0.5,
        chassisHeight * 0.5,
        chassisLength * 0.5
      )
    );
    var transform = new Ammo.btTransform();
    transform.setIdentity();
    transform.setOrigin(new Ammo.btVector3(0, 5, 0));
    transform.setRotation(
      new Ammo.btQuaternion(quat.x, quat.y, quat.z, quat.w)
    );
    var motionState = new Ammo.btDefaultMotionState(transform);
    var localInertia = new Ammo.btVector3(0, 0, 0);
    geometry.calculateLocalInertia(massVehicle, localInertia);

    let chassisMesh = this.createChassisMesh(
      chassisWidth,
      chassisHeight,
      chassisLength,
      blackMaterial,
      greenMaterial
    );

    var massOffset = new Ammo.btVector3(0, 0.4, 0);
    var transform2 = new Ammo.btTransform();
    transform2.setIdentity();
    transform2.setOrigin(massOffset);
    var compound = new Ammo.btCompoundShape();
    compound.addChildShape(transform2, geometry);

    var body = new Ammo.btRigidBody(
      new Ammo.btRigidBodyConstructionInfo(
        massVehicle,
        motionState,
        compound,
        localInertia
      )
    );
    body.setActivationState(4);

    physicsWorld.addRigidBody(body);

    var engineForce = 0;
    var vehicleSteering = 0;
    var breakingForce = 0;
    var tuning = new Ammo.btVehicleTuning();
    var rayCaster = new Ammo.btDefaultVehicleRaycaster(physicsWorld);
    var vehicle: any = new Ammo.btRaycastVehicle(tuning, body, rayCaster);
    vehicle.setCoordinateSystem(0, 1, 2);
    physicsWorld.addAction(vehicle);

    var trans = vehicle.getChassisWorldTransform();

    const addWheel = (
      isFront: any,
      pos: any,
      radius: any,
      width: any,
      index: any,
      blackMaterial: any
    ) => {
      var wheelInfo = vehicle.addWheel(
        pos,
        this.wheelDirectionCS0,
        this.wheelAxleCS,
        this.suspensionRestLength,
        radius,
        tuning,
        isFront
      );

      wheelInfo.set_m_suspensionStiffness(this.suspensionStiffness);
      wheelInfo.set_m_wheelsDampingRelaxation(this.suspensionDamping);
      wheelInfo.set_m_wheelsDampingCompression(this.suspensionCompression);
      wheelInfo.set_m_maxSuspensionForce(600000);
      wheelInfo.set_m_frictionSlip(40);
      wheelInfo.set_m_rollInfluence(this.rollInfluence);

      this.wheelMeshes[index] = this.createWheelMesh(
        radius,
        width,
        blackMaterial
      );
    };

    addWheel(
      true,
      new Ammo.btVector3(
        this.wheelHalfTrackFront,
        this.wheelAxisHeightFront,
        this.wheelAxisFrontPosition
      ),
      this.wheelRadiusFront,
      this.wheelWidthFront,
      this.FRONT_LEFT,
      blackMaterial
    );
    addWheel(
      true,
      new Ammo.btVector3(
        -this.wheelHalfTrackFront,
        this.wheelAxisHeightFront,
        this.wheelAxisFrontPosition
      ),
      this.wheelRadiusFront,
      this.wheelWidthFront,
      this.FRONT_RIGHT,
      blackMaterial
    );
    addWheel(
      false,
      new Ammo.btVector3(
        -this.wheelHalfTrackBack,
        this.wheelAxisHeightBack,
        this.wheelAxisPositionBack
      ),
      this.wheelRadiusBack,
      this.wheelWidthBack,
      this.BACK_LEFT,
      blackMaterial
    );
    addWheel(
      false,
      new Ammo.btVector3(
        this.wheelHalfTrackBack,
        this.wheelAxisHeightBack,
        this.wheelAxisPositionBack
      ),
      this.wheelRadiusBack,
      this.wheelWidthBack,
      this.BACK_RIGHT,
      blackMaterial
    );

    this.vehicleReady = true;
  }

  eateChassisMesh(w: any, l: any, h: any, greenMaterial: any) {
    let scene = this.scene;

    var mesh = MeshBuilder.CreateBox(
      "box",
      { width: w, depth: h, height: l },
      scene
    );
    mesh.rotationQuaternion = new Quaternion();
    mesh.material = greenMaterial;

    var camera = new FollowCamera("FollowCam", new Vector3(0, 10, -10), scene);
    camera.radius = 10;
    camera.heightOffset = 4;
    camera.rotationOffset = 0;
    camera.cameraAcceleration = 0.05;
    camera.maxCameraSpeed = 400;
    // camera.attachControl(canvas, true);
    camera.lockedTarget = mesh; //version 2.5 onwards
    scene.activeCamera = camera;

    return mesh;
  }

  createWheelMesh(radius: any, width: any, blackMaterial: any) {
    //var mesh = new BABYLON.MeshBuilder.CreateBox("wheel", {width:.82, height:.82, depth:.82}, scene);
    var mesh = MeshBuilder.CreateCylinder(
      "Wheel",
      { diameter: 1, height: 0.5, tessellation: 6 },
      this.scene
    );
    mesh.rotationQuaternion = new Quaternion();
    mesh.material = blackMaterial;

    return mesh;
  }

  keyup(e: any) {
    if (this.keysActions[e.code]) {
      this.actions[this.keysActions[e.code]] = false;
      //e.preventDefault();
      //e.stopPropagation();

      //return false;
    }
  }

  keydown(e: any) {
    if (this.keysActions[e.code]) {
      this.actions[this.keysActions[e.code]] = true;
      //e.preventDefault();
      //e.stopPropagation();

      //return false;
    }
  }

  createChassisMesh(
    w: any,
    l: any,
    h: any,
    blackMaterial: any,
    greenMaterial: any
  ) {
    var mesh = MeshBuilder.CreateBox(
      "box",
      { width: w, depth: h, height: l },
      this.scene
    );
    mesh.rotationQuaternion = new Quaternion();
    mesh.material = greenMaterial;

    var camera = new FollowCamera(
      "FollowCam",
      new Vector3(0, 10, -10),
      this.scene
    );
    camera.radius = 10;
    camera.heightOffset = 4;
    camera.rotationOffset = 0;
    camera.cameraAcceleration = 0.05;
    camera.maxCameraSpeed = 400;
    // camera.attachControl(canvas, true);
    camera.lockedTarget = mesh; //version 2.5 onwards
    this.scene.activeCamera = camera;

    return mesh;
  }
}
